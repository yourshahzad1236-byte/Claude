# HRD synonyms

| Synonym | Target |
|---|---|
